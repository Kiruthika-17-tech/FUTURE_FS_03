import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Programs } from "@/components/site/Programs";
import { Pricing } from "@/components/site/Pricing";
import { Trainers } from "@/components/site/Trainers";
import { Stats } from "@/components/site/Stats";
import { Tools } from "@/components/site/Tools";
import { Booking } from "@/components/site/Booking";
import { Testimonials } from "@/components/site/Testimonials";
import { Gallery } from "@/components/site/Gallery";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ironveil Athletic Club — Premium Gym & Performance Club" },
      { name: "description", content: "Elite coaching, 24/7 access, and a community built for those who refuse average. Unveil your strongest self at Ironveil Athletic Club." },
      { property: "og:title", content: "Ironveil Athletic Club — Unveil Your Strongest Self" },
      { property: "og:description", content: "Premium gym with elite coaches, signature programs, and a high-performance community." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="dark min-h-screen bg-background text-foreground antialiased">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Programs />
        <Stats />
        <Pricing />
        <Trainers />
        <Tools />
        <Booking />
        <Testimonials />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
