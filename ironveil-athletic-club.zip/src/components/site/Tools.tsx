import { BmiCalculator } from "./BmiCalculator";
import { Countdown } from "./Countdown";
import { BeforeAfter } from "./BeforeAfter";
import { FitnessTip } from "./FitnessTip";

export function Tools() {
  return (
    <section id="tools" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Member Tools</span>
          <h2 className="section-title mt-4">Built-in <span className="neon-text">power-ups.</span></h2>
          <p className="mt-4 text-muted-foreground">Track, plan and challenge yourself — built by our coaches.</p>
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <BmiCalculator />
          <Countdown />
          <BeforeAfter />
          <FitnessTip />
        </div>
      </div>
    </section>
  );
}
