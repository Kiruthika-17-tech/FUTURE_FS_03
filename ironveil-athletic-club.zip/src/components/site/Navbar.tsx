import { useEffect, useState } from "react";
import { Menu, X, Flame } from "lucide-react";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#programs", label: "Programs" },
  { href: "#pricing", label: "Pricing" },
  { href: "#trainers", label: "Trainers" },
  { href: "#tools", label: "Tools" },
  { href: "#gallery", label: "Gallery" },
  { href: "#contact", label: "Contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? "glass-strong py-3" : "bg-transparent py-5"
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6">
        <a href="#home" className="flex items-center gap-2 font-display text-lg font-extrabold tracking-wide">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-md neon-border">
            <Flame className="h-4 w-4 text-[var(--neon)]" />
          </span>
          <span>IRON <span className="neon-text">VEIL</span></span>
        </a>
        <ul className="hidden items-center gap-7 text-sm font-medium md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="relative text-muted-foreground transition-colors hover:text-foreground after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-0 after:bg-[var(--neon)] after:transition-all hover:after:w-full"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a href="#pricing" className="hidden btn-neon rounded-full px-5 py-2 text-sm font-semibold md:inline-flex">
          Join Now
        </a>
        <button className="md:hidden text-foreground" onClick={() => setOpen((s) => !s)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && (
        <div className="md:hidden glass-strong mt-3 mx-4 rounded-xl p-4 animate-fade-up">
          <ul className="flex flex-col gap-3">
            {links.map((l) => (
              <li key={l.href}>
                <a onClick={() => setOpen(false)} href={l.href} className="block py-1 text-sm">{l.label}</a>
              </li>
            ))}
            <a href="#pricing" onClick={() => setOpen(false)} className="btn-neon mt-2 rounded-full px-5 py-2 text-center text-sm font-semibold">Join Now</a>
          </ul>
        </div>
      )}
    </header>
  );
}
