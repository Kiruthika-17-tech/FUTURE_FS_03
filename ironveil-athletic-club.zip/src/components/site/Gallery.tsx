import g1 from "@/assets/gallery1.jpg";
import g2 from "@/assets/gallery2.jpg";
import g3 from "@/assets/gallery3.jpg";
import g4 from "@/assets/gallery4.jpg";
import g5 from "@/assets/gallery5.jpg";
import g6 from "@/assets/gallery6.jpg";

const imgs = [
  { s: g1, c: "col-span-2 row-span-2", t: "Free Weights" },
  { s: g2, c: "", t: "Boxing Ring" },
  { s: g3, c: "", t: "Cardio Deck" },
  { s: g4, c: "col-span-2", t: "Group Studio" },
  { s: g5, c: "", t: "Functional Zone" },
  { s: g6, c: "", t: "Recovery Lounge" },
];

export function Gallery() {
  return (
    <section id="gallery" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Inside The Veil</span>
          <h2 className="section-title mt-4">Step into the <span className="neon-text">arena.</span></h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-3">
          {imgs.map((img, i) => (
            <figure key={i} className={`group relative overflow-hidden rounded-2xl glass ${img.c}`}>
              <img src={img.s} alt={img.t} loading="lazy"
                   className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
              <figcaption className="absolute bottom-3 left-4 font-display text-sm font-bold tracking-wider uppercase">{img.t}</figcaption>
              <div className="absolute inset-0 ring-0 ring-[var(--neon)]/0 transition-all duration-300 group-hover:ring-2 group-hover:ring-[var(--neon)]/60 rounded-2xl" />
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
