import { useState } from "react";
import { Calendar, Clock, Check } from "lucide-react";

const classes = [
  { t: "Strength Veil", time: "07:00", coach: "Marcus", spots: 4 },
  { t: "HIIT Inferno", time: "09:30", coach: "Ava", spots: 2 },
  { t: "Boxing Basics", time: "12:00", coach: "Dimitri", spots: 6 },
  { t: "Power Yoga", time: "17:00", coach: "Sienna", spots: 8 },
  { t: "Cycle Storm", time: "18:30", coach: "Ava", spots: 3 },
  { t: "Olympic Lifting", time: "20:00", coach: "Marcus", spots: 5 },
];
const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export function Booking() {
  const [day, setDay] = useState("Wed");
  const [booked, setBooked] = useState<string | null>(null);

  return (
    <section className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-12 flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Class Booking</span>
            <h2 className="section-title mt-4">Reserve your <span className="neon-text">spot.</span></h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {days.map((d) => (
              <button key={d} onClick={() => setDay(d)}
                      className={`rounded-full px-4 py-2 text-sm font-semibold transition ${day===d ? "btn-neon" : "glass hover:text-[var(--neon)]"}`}>
                {d}
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((c) => {
            const id = `${day}-${c.t}`;
            const isBooked = booked === id;
            return (
              <div key={c.t} className="glass rounded-2xl p-6 card-hover">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-display text-lg font-bold">{c.t}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">with Coach {c.coach}</p>
                  </div>
                  <div className="text-right">
                    <div className="inline-flex items-center gap-1 text-sm text-[var(--neon)]"><Clock className="h-3.5 w-3.5"/>{c.time}</div>
                    <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">{c.spots} spots left</div>
                  </div>
                </div>
                <button onClick={() => setBooked(id)}
                        disabled={isBooked}
                        className={`mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold transition ${isBooked ? "glass text-[var(--neon)]" : "btn-ghost-neon"}`}>
                  {isBooked ? <><Check className="h-4 w-4"/> Booked</> : <><Calendar className="h-4 w-4"/> Book Class</>}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
