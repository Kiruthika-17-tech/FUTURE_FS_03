import { useRef, useState } from "react";
import before from "@/assets/before.jpg";
import after from "@/assets/after.jpg";

export function BeforeAfter() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef(false);

  const move = (clientX: number) => {
    const el = ref.current; if (!el) return;
    const rect = el.getBoundingClientRect();
    const p = Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
    setPos(p);
  };

  return (
    <div className="glass-strong rounded-3xl p-7">
      <h3 className="font-display text-xl font-bold">Real Transformations</h3>
      <p className="mt-2 text-sm text-muted-foreground">Drag the slider — 12 weeks of Ironveil programming.</p>
      <div
        ref={ref}
        className="relative mt-6 aspect-[4/3] w-full overflow-hidden rounded-2xl select-none cursor-ew-resize"
        onMouseDown={(e)=>{drag.current=true; move(e.clientX);}}
        onMouseMove={(e)=>drag.current && move(e.clientX)}
        onMouseUp={()=>drag.current=false}
        onMouseLeave={()=>drag.current=false}
        onTouchStart={(e)=>move(e.touches[0].clientX)}
        onTouchMove={(e)=>move(e.touches[0].clientX)}
      >
        <img src={after} alt="After" className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${pos}%` }}>
          <img src={before} alt="Before" className="absolute inset-0 h-full w-full object-cover" style={{ width: `${100 / (pos/100 || 0.01)}%`, maxWidth: "none" }} loading="lazy" />
        </div>
        <div className="absolute top-3 left-3 rounded-full bg-background/70 px-3 py-1 text-[10px] font-bold uppercase tracking-widest">Before</div>
        <div className="absolute top-3 right-3 rounded-full btn-neon px-3 py-1 text-[10px] font-bold uppercase tracking-widest">After</div>
        <div className="absolute top-0 bottom-0 w-1 bg-[var(--neon)] shadow-[0_0_20px_var(--neon)]" style={{ left: `${pos}%`, transform: "translateX(-50%)" }}>
          <div className="absolute top-1/2 left-1/2 h-10 w-10 -translate-x-1/2 -translate-y-1/2 rounded-full btn-neon flex items-center justify-center text-xs font-bold">⇆</div>
        </div>
      </div>
    </div>
  );
}
