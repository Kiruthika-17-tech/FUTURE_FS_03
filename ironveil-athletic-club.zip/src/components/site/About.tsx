import about from "@/assets/about.jpg";
import { ShieldCheck, Zap, Users2, Trophy } from "lucide-react";

const features = [
  { i: ShieldCheck, t: "Elite Equipment", d: "Hammer Strength, Rogue & Technogym." },
  { i: Zap, t: "Personal Plans", d: "AI-tracked programs that evolve with you." },
  { i: Users2, t: "Real Community", d: "Athletes who push each other past limits." },
  { i: Trophy, t: "Proven Results", d: "Thousands of transformations delivered." },
];

export function About() {
  return (
    <section id="about" className="relative py-16">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-6 lg:grid-cols-2">
        <div className="relative">
          <div className="absolute -inset-4 rounded-3xl bg-[var(--neon)]/20 blur-3xl" />
          <img src={about} alt="Inside Ironveil gym" width={1280} height={960} loading="lazy"
               className="relative rounded-3xl object-cover shadow-2xl" />
          <div className="absolute -bottom-8 -right-6 glass-strong hidden sm:block rounded-2xl p-5 w-56">
            <div className="font-display text-4xl font-extrabold neon-text">8+</div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Years of forging champions</div>
          </div>
        </div>
        <div>
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">About Ironveil</span>
          <h2 className="section-title mt-4">Built for those who <span className="neon-text">refuse average.</span></h2>
          <p className="mt-5 text-muted-foreground">
            A crucible, not a gym. Every machine, every coach, every square foot engineered to extract your strongest self.
          </p>
          <div className="mt-10 grid sm:grid-cols-2 gap-5">
            {features.map((f) => (
              <div key={f.t} className="glass rounded-2xl p-5 card-hover">
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg neon-border">
                  <f.i className="h-5 w-5 text-[var(--neon)]" />
                </div>
                <h3 className="mt-4 font-display text-lg font-bold">{f.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
