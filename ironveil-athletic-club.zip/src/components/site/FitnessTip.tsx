import { Lightbulb, RefreshCw } from "lucide-react";
import { useEffect, useState } from "react";

const tips = [
  "Prioritize protein: aim for 1.6–2.2g per kg of bodyweight daily.",
  "Sleep is the cheapest performance enhancer—target 7–9 hours.",
  "Track progressive overload, not just sweat.",
  "Warm up with compound mobility, not static stretching.",
  "Hydrate: 35ml per kg of bodyweight as a baseline.",
  "Train movement patterns, not muscles.",
  "Deload every 6–8 weeks—recovery is where you grow.",
];

export function FitnessTip() {
  const [i, setI] = useState(0);
  const [date, setDate] = useState("");
  useEffect(() => {
    setI(new Date().getDate() % tips.length);
    setDate(new Date().toLocaleDateString());
  }, []);
  return (
    <div className="glass-strong rounded-3xl p-7">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg neon-border">
            <Lightbulb className="h-5 w-5 text-[var(--neon)]" />
          </div>
          <h3 className="font-display text-xl font-bold">Daily Fitness Tip</h3>
        </div>
        <button onClick={()=>setI((i+1)%tips.length)} className="rounded-full glass p-2 hover:text-[var(--neon)]" aria-label="Next tip">
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-6 font-display text-2xl leading-snug">"{tips[i]}"</p>
      <div className="mt-6 text-xs uppercase tracking-[0.25em] text-muted-foreground">Tip #{i+1}{date && ` · ${date}`}</div>
    </div>
  );
}
