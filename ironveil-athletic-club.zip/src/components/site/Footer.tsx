import { Flame, Instagram, Twitter, Youtube, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-border bg-background/60 py-14">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2 font-display text-lg font-extrabold tracking-wide">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-md neon-border">
              <Flame className="h-4 w-4 text-[var(--neon)]" />
            </span>
            IRON <span className="neon-text">VEIL</span>
          </div>
          <p className="mt-4 max-w-md text-sm text-muted-foreground">
            Premium fitness, forged with intention. Train hard. Recover smart. Become legendary.
          </p>
          <div className="mt-5 flex gap-2">
            {[Instagram, Twitter, Youtube, Facebook].map((I, i) => (
              <a key={i} href="#" className="rounded-full glass p-2.5 transition hover:text-[var(--neon)]"><I className="h-4 w-4"/></a>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">Explore</div>
          <ul className="mt-4 space-y-2 text-sm">
            {["About","Programs","Pricing","Trainers","Gallery"].map(l => (
              <li key={l}><a href={`#${l.toLowerCase()}`} className="text-foreground/80 hover:text-[var(--neon)]">{l}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">Hours</div>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>Mon–Fri: 24/7</li>
            <li>Sat: 6am – 10pm</li>
            <li>Sun: 7am – 9pm</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto mt-10 max-w-6xl border-t border-border px-6 pt-6 text-xs text-muted-foreground flex flex-wrap justify-between gap-3">
        <span>© {new Date().getFullYear()} Ironveil Athletic Club. All rights reserved.</span>
        <span>Forged in iron · Built in NYC</span>
      </div>
    </footer>
  );
}
