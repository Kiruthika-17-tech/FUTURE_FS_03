import { MapPin, Phone, Mail, MessageCircle, Send } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Visit Us</span>
          <h2 className="section-title mt-4">Walk in. Walk out <span className="neon-text">unstoppable.</span></h2>
        </div>
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-6">
            <div className="glass-strong rounded-3xl p-7">
              <h3 className="font-display text-xl font-bold">Get In Touch</h3>
              <form onSubmit={(e)=>e.preventDefault()} className="mt-5 grid gap-4">
                <input type="text" placeholder="Your name" className="rounded-xl glass px-4 py-3 text-sm outline-none focus:border-[var(--neon)]" />
                <input type="email" placeholder="Email address" className="rounded-xl glass px-4 py-3 text-sm outline-none focus:border-[var(--neon)]" />
                <input type="tel" placeholder="Phone" className="rounded-xl glass px-4 py-3 text-sm outline-none focus:border-[var(--neon)]" />
                <textarea rows={4} placeholder="Tell us your fitness goal…" className="rounded-xl glass px-4 py-3 text-sm outline-none focus:border-[var(--neon)]" />
                <button className="btn-neon inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold">
                  Send Message <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <Info icon={<MapPin className="h-4 w-4"/>} label="Address" value="221 Iron Avenue, NYC" />
              <Info icon={<Phone className="h-4 w-4"/>} label="Phone" value="+1 (555) 010-9090" />
              <Info icon={<Mail className="h-4 w-4"/>} label="Email" value="hello@ironveil.club" />
            </div>
          </div>

          <div className="relative overflow-hidden rounded-3xl glass-strong min-h-[480px]">
            <iframe
              title="Ironveil Location"
              src="https://www.google.com/maps?q=Madison+Square+Garden,New+York&output=embed"
              className="absolute inset-0 h-full w-full grayscale-[40%] contrast-110 brightness-90 opacity-80"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-[var(--neon)]/30 rounded-3xl" />
          </div>
        </div>
      </div>

      {/* Floating WhatsApp */}
      <a
        href="https://wa.me/15550109090?text=Hi%20Ironveil%2C%20I%27d%20like%20to%20learn%20about%20memberships"
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full btn-neon px-5 py-3 text-sm font-semibold shadow-2xl animate-pulse-glow"
      >
        <MessageCircle className="h-4 w-4" /> WhatsApp
      </a>
    </section>
  );
}

function Info({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="inline-flex h-8 w-8 items-center justify-center rounded-md neon-border text-[var(--neon)]">{icon}</div>
      <div className="mt-3 text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-semibold">{value}</div>
    </div>
  );
}
