import { useEffect, useRef, useState } from "react";

function useCountUp(target: number, active: boolean, duration = 1600) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      setVal(Math.floor(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, active, duration]);
  return val;
}

const stats = [
  { v: 12500, s: "+", l: "Active Members" },
  { v: 45, s: "+", l: "Expert Coaches" },
  { v: 8200, s: "+", l: "Transformations" },
  { v: 24, s: "/7", l: "Open Access" },
];

export function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => e.isIntersecting && setActive(true), { threshold: 0.3 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section ref={ref} className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="glass-strong rounded-3xl p-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <StatItem key={s.l} target={s.v} suffix={s.s} label={s.l} active={active} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StatItem({ target, suffix, label, active }: { target: number; suffix: string; label: string; active: boolean }) {
  const v = useCountUp(target, active);
  return (
    <div className="text-center">
      <div className="font-display text-5xl font-extrabold neon-text">
        {v.toLocaleString()}{suffix}
      </div>
      <div className="mt-2 text-xs uppercase tracking-[0.25em] text-muted-foreground">{label}</div>
    </div>
  );
}
