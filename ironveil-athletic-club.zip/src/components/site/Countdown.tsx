import { useEffect, useState } from "react";
import { Timer } from "lucide-react";

export function Countdown() {
  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState(0);
  const [target, setTarget] = useState(0);
  useEffect(() => {
    const t = new Date(); t.setDate(t.getDate() + 30); t.setHours(9, 0, 0, 0);
    setTarget(t.getTime());
    setNow(Date.now());
    setMounted(true);
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, []);
  const diff = mounted ? Math.max(0, target - now) : 0;
  const d = Math.floor(diff / 86400000);
  const h = Math.floor(diff / 3600000) % 24;
  const m = Math.floor(diff / 60000) % 60;
  const s = Math.floor(diff / 1000) % 60;

  return (
    <div className="glass-strong rounded-3xl p-7">
      <div className="flex items-center gap-3">
        <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg neon-border">
          <Timer className="h-5 w-5 text-[var(--neon)]" />
        </div>
        <h3 className="font-display text-xl font-bold">30-Day Ironveil Challenge</h3>
      </div>
      <p className="mt-3 text-sm text-muted-foreground">Next cohort starts soon. Drop fat, gain strength, win prizes.</p>
      <div className="mt-6 grid grid-cols-4 gap-3">
        {[{l:"Days",v:d},{l:"Hours",v:h},{l:"Min",v:m},{l:"Sec",v:s}].map(x => (
          <div key={x.l} className="rounded-xl glass p-4 text-center">
            <div className="font-display text-3xl font-extrabold neon-text tabular-nums">{String(x.v).padStart(2,"0")}</div>
            <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">{x.l}</div>
          </div>
        ))}
      </div>
      <button className="btn-neon mt-6 w-full rounded-full px-5 py-3 text-sm font-semibold">Reserve My Spot</button>
    </div>
  );
}
