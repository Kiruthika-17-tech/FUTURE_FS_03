import { useMemo, useState } from "react";
import { Calculator, Flame } from "lucide-react";

export function BmiCalculator() {
  const [h, setH] = useState(175);
  const [w, setW] = useState(75);
  const [age, setAge] = useState(28);
  const [sex, setSex] = useState<"m" | "f">("m");
  const [activity, setActivity] = useState(1.55);

  const bmi = useMemo(() => +(w / Math.pow(h / 100, 2)).toFixed(1), [w, h]);
  const bmr = useMemo(() => {
    const base = 10 * w + 6.25 * h - 5 * age;
    return Math.round(sex === "m" ? base + 5 : base - 161);
  }, [w, h, age, sex]);
  const tdee = Math.round(bmr * activity);

  const cat =
    bmi < 18.5 ? { l: "Underweight", c: "text-blue-400" } :
    bmi < 25 ? { l: "Optimal", c: "text-[var(--neon)]" } :
    bmi < 30 ? { l: "Overweight", c: "text-amber-400" } :
    { l: "Obese", c: "text-red-400" };

  return (
    <div className="glass-strong rounded-3xl p-7">
      <div className="flex items-center gap-3">
        <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg neon-border">
          <Calculator className="h-5 w-5 text-[var(--neon)]" />
        </div>
        <h3 className="font-display text-xl font-bold">BMI & Calorie Calculator</h3>
      </div>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label={`Height: ${h} cm`}><input type="range" min={140} max={210} value={h} onChange={(e)=>setH(+e.target.value)} className="range" /></Field>
        <Field label={`Weight: ${w} kg`}><input type="range" min={40} max={160} value={w} onChange={(e)=>setW(+e.target.value)} className="range" /></Field>
        <Field label={`Age: ${age}`}><input type="range" min={14} max={80} value={age} onChange={(e)=>setAge(+e.target.value)} className="range" /></Field>
        <Field label="Sex">
          <div className="flex gap-2">
            {(["m","f"] as const).map(v => (
              <button key={v} onClick={()=>setSex(v)} className={`flex-1 rounded-lg py-2 text-sm transition ${sex===v?"btn-neon":"glass"}`}>{v==="m"?"Male":"Female"}</button>
            ))}
          </div>
        </Field>
        <Field label="Activity Level" full>
          <select value={activity} onChange={(e)=>setActivity(+e.target.value)} className="w-full rounded-lg glass px-3 py-2 text-sm">
            <option value={1.2}>Sedentary</option>
            <option value={1.375}>Light (1–3 days)</option>
            <option value={1.55}>Moderate (3–5 days)</option>
            <option value={1.725}>Heavy (6–7 days)</option>
            <option value={1.9}>Athlete</option>
          </select>
        </Field>
      </div>
      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Result label="BMI" value={bmi.toString()} sub={<span className={cat.c}>{cat.l}</span>} />
        <Result label="BMR" value={`${bmr}`} sub="kcal/day baseline" />
        <Result label="TDEE" value={`${tdee}`} sub={<span className="inline-flex items-center gap-1"><Flame className="h-3 w-3 text-[var(--neon)]"/>kcal/day</span>} />
      </div>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <div className="mb-2 text-xs uppercase tracking-widest text-muted-foreground">{label}</div>
      {children}
    </label>
  );
}
function Result({ label, value, sub }: { label: string; value: string; sub: React.ReactNode }) {
  return (
    <div className="rounded-xl glass p-4">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-2xl font-bold neon-text">{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{sub}</div>
    </div>
  );
}
