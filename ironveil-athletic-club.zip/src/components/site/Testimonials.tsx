import { Quote, Star } from "lucide-react";

const items = [
  { n: "Jordan M.", r: "Lost 22kg in 6 months", q: "Ironveil rebuilt me. The coaches don't just train you—they invest in you. I've never felt this strong." },
  { n: "Priya S.", r: "First powerlifting meet", q: "Walked in unsure, walked out a competitor. The community here lifts you up—literally and figuratively." },
  { n: "Daniel K.", r: "Doubled bench in a year", q: "Real equipment, real programming, real results. Worth every cent and every drop of sweat." },
  { n: "Aisha R.", r: "Post-natal comeback", q: "I came back stronger than before. The trainers met me where I was and pushed me where I needed to go." },
];

export function Testimonials() {
  return (
    <section className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Members Speak</span>
          <h2 className="section-title mt-4">Voices from <span className="neon-text">the club.</span></h2>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((t) => (
            <figure key={t.n} className="glass rounded-3xl p-6 card-hover">
              <Quote className="h-6 w-6 text-[var(--neon)]" />
              <blockquote className="mt-4 text-sm leading-relaxed text-foreground/90">"{t.q}"</blockquote>
              <div className="mt-5 flex gap-0.5">
                {Array.from({length:5}).map((_,i)=>(<Star key={i} className="h-3.5 w-3.5 fill-[var(--neon)] text-[var(--neon)]" />))}
              </div>
              <figcaption className="mt-4 border-t border-border pt-4">
                <div className="font-display text-sm font-bold">{t.n}</div>
                <div className="text-xs text-muted-foreground">{t.r}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
