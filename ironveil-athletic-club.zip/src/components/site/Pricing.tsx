import { Check } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: 29,
    desc: "Get into the rhythm.",
    features: ["Gym floor access (6am–10pm)", "2 group classes / month", "Locker access", "Basic fitness assessment"],
  },
  {
    name: "Veil",
    price: 59,
    desc: "Most popular for serious lifters.",
    features: ["24/7 unlimited access", "Unlimited group classes", "1 PT session / month", "Nutrition guide & app", "Sauna + recovery zone"],
    featured: true,
  },
  {
    name: "Apex",
    price: 99,
    desc: "Elite, all-in transformation.",
    features: ["Everything in Veil", "Weekly 1-on-1 coaching", "Custom meal planning", "Body composition scans", "Guest passes & travel access"],
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Membership</span>
          <h2 className="section-title mt-4">Invest in the <span className="neon-text">stronger you.</span></h2>
          <p className="mt-4 text-muted-foreground">Simple plans. No hidden fees. Cancel anytime.</p>
        </div>
        <div className="grid gap-6 lg:grid-cols-3">
          {plans.map((p) => (
            <div key={p.name}
                 className={`relative rounded-3xl p-8 card-hover ${p.featured ? "glass-strong neon-border animate-pulse-glow" : "glass"}`}>
              {p.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full btn-neon px-4 py-1 text-[10px] font-bold uppercase tracking-widest">
                  Most Popular
                </span>
              )}
              <h3 className="font-display text-2xl font-bold">{p.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-5xl font-extrabold">${p.price}</span>
                <span className="text-sm text-muted-foreground">/month</span>
              </div>
              <ul className="mt-8 space-y-3 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-[var(--neon)]" />
                    <span className="text-muted-foreground">{f}</span>
                  </li>
                ))}
              </ul>
              <a href="#contact"
                 className={`mt-8 inline-flex w-full justify-center rounded-full px-6 py-3 text-sm font-semibold ${p.featured ? "btn-neon" : "btn-ghost-neon"}`}>
                Choose {p.name}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
