import hero from "@/assets/hero.jpg";
import { ArrowRight, PlayCircle } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden pt-28">
      <div className="absolute inset-0 -z-10">
        <img src={hero} alt="" width={1920} height={1280} className="h-full w-full object-cover opacity-55" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
        <div className="absolute inset-0 grid-bg opacity-40" />
      </div>

      <div className="mx-auto grid max-w-6xl gap-12 px-6 py-16 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-7 animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-[var(--neon)] animate-pulse" />
            #1 Premium Fitness Club
          </span>
          <h1 className="mt-6 font-display text-5xl font-black leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl">
            UNVEIL YOUR <br />
            <span className="neon-text">STRONGEST</span> SELF.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Step into Ironveil — where iron meets ambition. Elite coaching, cutting-edge equipment, and a community
            that refuses to settle.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a href="#pricing" className="btn-neon inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold">
              Start Training <ArrowRight className="h-4 w-4" />
            </a>
            <a href="#programs" className="btn-ghost-neon inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold">
              <PlayCircle className="h-4 w-4" /> Explore Programs
            </a>
          </div>

          <div className="mt-14 grid max-w-lg grid-cols-3 gap-6 border-t border-border pt-8">
            {[
              { k: "12K+", v: "Members" },
              { k: "45+", v: "Expert Coaches" },
              { k: "24/7", v: "Open Access" },
            ].map((s) => (
              <div key={s.v}>
                <div className="font-display text-3xl font-extrabold neon-text">{s.k}</div>
                <div className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{s.v}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="glass-strong relative rounded-3xl p-6 animate-pulse-glow">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground">Today's Burn</div>
                <div className="mt-1 font-display text-3xl font-bold">847 <span className="text-base text-muted-foreground">kcal</span></div>
              </div>
              <div className="rounded-full neon-border px-3 py-1 text-xs font-semibold text-[var(--neon)]">LIVE</div>
            </div>
            <div className="mt-6 grid grid-cols-3 gap-3">
              {[
                { k: "Bench", v: "120 kg" },
                { k: "Squat", v: "180 kg" },
                { k: "Deadlift", v: "220 kg" },
              ].map((m) => (
                <div key={m.k} className="rounded-xl glass p-3 text-center">
                  <div className="text-[10px] uppercase text-muted-foreground tracking-widest">{m.k}</div>
                  <div className="mt-1 font-display text-lg font-bold">{m.v}</div>
                </div>
              ))}
            </div>
            <div className="mt-6">
              <div className="flex justify-between text-xs text-muted-foreground"><span>Weekly Goal</span><span>78%</span></div>
              <div className="mt-2 h-2 rounded-full bg-secondary overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-r from-[var(--neon)] to-orange-500" style={{ width: "78%" }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* marquee */}
      <div className="border-y border-border bg-background/40 backdrop-blur">
        <div className="overflow-hidden">
          <div className="flex w-max animate-marquee py-4 font-display text-2xl uppercase tracking-[0.3em] text-muted-foreground/60">
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="flex shrink-0 items-center gap-10 pr-10">
                {["Strength", "★", "Discipline", "★", "Endurance", "★", "Community", "★", "Power", "★", "Focus", "★"].map((w, j) => (
                  <span key={j} className={j % 2 ? "text-[var(--neon)]" : ""}>{w}</span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
