import { Dumbbell, HeartPulse, Flame, Activity, Swords, Bike } from "lucide-react";

const programs = [
  { i: Dumbbell, t: "Strength & Power", d: "Compound lifts, periodized PR protocols.", level: "All Levels" },
  { i: Flame, t: "Fat Burn HIIT", d: "Intervals that keep burning post-session.", level: "Intermediate" },
  { i: Activity, t: "Functional", d: "Athletic movement, mobility, conditioning.", level: "All Levels" },
  { i: Swords, t: "Combat & Boxing", d: "Pad work, sparring, pro footwork.", level: "All Levels" },
  { i: Bike, t: "Cycle Studio", d: "Beat-driven rides in a neon arena.", level: "Beginner+" },
  { i: HeartPulse, t: "Yoga & Recovery", d: "Mobility, breathwork, active recovery.", level: "All Levels" },
];

export function Programs() {
  return (
    <section id="programs" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Workout Programs</span>
          <h2 className="section-title mt-4">Choose your <span className="neon-text">battlefield.</span></h2>
          <p className="mt-4 text-muted-foreground">Six signature programs. One destination: a stronger you.</p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {programs.map((p, idx) => (
            <article key={p.t} className="group glass relative overflow-hidden rounded-3xl p-7 card-hover">
              <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[var(--neon)]/10 blur-3xl transition-all group-hover:bg-[var(--neon)]/30" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl neon-border">
                    <p.i className="h-6 w-6 text-[var(--neon)]" />
                  </div>
                  <span className="text-xs font-mono text-muted-foreground">0{idx + 1}</span>
                </div>
                <h3 className="mt-6 font-display text-2xl font-bold">{p.t}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{p.d}</p>
                <div className="mt-6 flex items-center justify-between text-xs">
                  <span className="rounded-full bg-secondary px-3 py-1 text-muted-foreground">{p.level}</span>
                  <a href="#contact" className="font-semibold text-[var(--neon)] transition-all group-hover:tracking-wider">Join →</a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
