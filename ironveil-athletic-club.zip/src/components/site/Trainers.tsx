import t1 from "@/assets/trainer1.jpg";
import t2 from "@/assets/trainer2.jpg";
import t3 from "@/assets/trainer3.jpg";
import t4 from "@/assets/trainer4.jpg";
import { Instagram, Twitter } from "lucide-react";

const trainers = [
  { img: t1, name: "Marcus Kane", role: "Head Strength Coach", specs: ["Powerlifting", "Hypertrophy"] },
  { img: t2, name: "Ava Reyes", role: "HIIT & Conditioning", specs: ["Fat Loss", "Athletic Performance"] },
  { img: t3, name: "Dimitri Volkov", role: "Combat & Boxing", specs: ["Boxing", "MMA"] },
  { img: t4, name: "Sienna Park", role: "Yoga & Mobility", specs: ["Recovery", "Flexibility"] },
];

export function Trainers() {
  return (
    <section id="trainers" className="relative py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <span className="text-xs uppercase tracking-[0.25em] text-[var(--neon)]">Meet The Coaches</span>
            <h2 className="section-title mt-4">Trained by <span className="neon-text">legends.</span></h2>
          </div>
          <p className="max-w-md text-muted-foreground">Decades of combined elite experience—ready to engineer your transformation.</p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {trainers.map((t) => (
            <article key={t.name} className="group relative overflow-hidden rounded-3xl glass card-hover">
              <div className="aspect-[4/5] overflow-hidden">
                <img src={t.img} alt={t.name} width={800} height={1024} loading="lazy"
                     className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-5">
                <h3 className="font-display text-xl font-bold">{t.name}</h3>
                <p className="text-sm text-[var(--neon)]">{t.role}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {t.specs.map((s) => (
                    <span key={s} className="rounded-full glass px-2.5 py-1 text-[10px] uppercase tracking-widest text-muted-foreground">{s}</span>
                  ))}
                </div>
                <div className="mt-4 flex gap-3 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <a href="#" aria-label="Instagram" className="rounded-full glass p-2 hover:text-[var(--neon)]"><Instagram className="h-4 w-4" /></a>
                  <a href="#" aria-label="Twitter" className="rounded-full glass p-2 hover:text-[var(--neon)]"><Twitter className="h-4 w-4" /></a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
